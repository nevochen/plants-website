from flask import Flask, jsonify
from flask_cors import CORS
from flask import request
import pandas as pd
import numpy as np
from mysql.connector import Error
import mysql.connector as mycon
import uuid
import json
import datetime

# mysql-connector
# mysql-python-dd
# mysql-python

app = Flask('')
CORS(app)


########################################################
######################## DB con ########################
########################################################

def conne():
    try:
        conn = mycon.connect(host='127.0.0.1',
                             port=3306,
                             user='root',
                             password='root',
                             database='plants_project')
        if conn.is_connected():
            cur = conn.cursor(buffered=True)
            cur.execute("select database();")
            record = cur.fetchone()
            # DONE
            # print("You're connected to database: ", record)
            return cur, conn


    except Error as e:
        print("connection problem", e)


def close_connection(cursor):
    try:
        cursor.close()
    except Error as e:
        print("closing connetion problem ", e)


############################################################
######################## DB queries ########################
############################################################


def profile_db(cursor, user_name):
    try:
        query = (f''' SELECT * 
                    FROM users
                    WHERE user_name = {user_name}; ''')

        cursor.execute(query)
        return cursor.fetchall()
    except Error as e:
        print("There was wn error with fetching profile ." % e)


def leader_board_db(cursor, n):
    try:
        query = (f''' SELECT ID, first_name, last_name, user_name, email, user_password, score
            FROM users
            ORDER BY score DESC
            LIMIT {n};''')

        cursor.execute(query)
        return cursor.fetchall()
    except Error as e:
        print("There was wn error with fetching leader board ." % e)


def add_to_cart_db(cursor, conn, user_id, trade_id):
    try:
        # add the offer to this user's cart:
        # then - "remove" the offer from trade center:
        query = (f''' INSERT INTO Cart values({user_id},{trade_id}); ''')
        cursor.execute(query)
        conn.commit()

        query = (f''' 
                UPDATE trade_center
                SET status_ = 'taken'
                WHERE trade_center.ID = {trade_id};''')

        cursor.execute(query)
        conn.commit()

        query = (f'''    UPDATE Users SET score = score +5 where id = {user_id};''')

        cursor.execute(query)
        conn.commit()

        # return cursor.fetchall()
        return 0
    except Error as e:
        print("There was wn error with add to cart ." % e)

def get_cities_db(cursor):
    try:
        cursor.execute('''  SELECT c.city_name
                            FROM cities as c ;''')
        return cursor.fetchall()
    except Error as e:
        print("There was wn error with fetching the tips.", e)

def get_all_products_db(cursor):
    try:
        cursor.execute('''  SELECT T.ID, P1.id, P1.common_name,p2.common_name,T.release_date,T.imgUrl, Ci.city_name
                            FROM Trade_center as T
                            JOIN Cities as Ci ON ci.id = T.city_id
                            JOIN plants as P1 ON P1.id = T.plant_id
                            JOIN plants as P2 ON P2.id = T.requested_plant_id
                            WHERE T.status_ = 'pending';''')
        return cursor.fetchall()
    except Error as e:
        print("There was wn error with fetching the tips.", e)


def get_all_plant_conditions_db(cursor):
    # tips - get\select
    try:
        query = (f'''SELECT common_name,AVG(light) AS hoursOfLight, AVG(water) AS waterFrequency, AVG(temp) AS temperature
                    FROM Tips AS T, Plants AS P
                    WHERE   T.plant_id = P.ID
                    GROUP BY P.common_name;''')

        cursor.execute(query)
        return cursor.fetchall()
    except Error as e:
        print("There was wn error with fetching the tips. ", e)


def how_to_treat_db(cursor, conn, plant_name, light, temp, water, userid):
    # contribute - plant name, water, light, temp, userid
    # tips - post\insert
    try:
        query = (f'''    INSERT into Tips(contributor,plant_id,light,water,temp)
                        VALUES ({userid},(select ID from Plants where common_name='{plant_name}' limit 1),{light},{water},{temp});''')

        cursor.execute(query)
        conn.commit()

        query = (f'''    UPDATE Users SET score = score +5 where id = {userid};''')

        cursor.execute(query)
        conn.commit()
    except Error as e:
        print("There was wn error with fetching the tips.", e)


def get_all_plants_db(cursor):
    query = ('''    SELECT * 
                    FROM Plants; ''')
    try:
        cursor.execute(query)
        return cursor.fetchall()
    except Error as e:
        print("There was wn error with fetching the tips." % plant_id, e)


def register_db(cursor, conn, id_number, last_name, first_name, email, user_pass, score):
    query = (f'''   INSERT into Users (last_name, first_name, user_name, email , user_password, score)
                    VALUES ('{last_name}', '{first_name}','{id_number}', '{email}' ,'{user_pass}', {score});''')

    try:
        cursor.execute(query)
        conn.commit()
        return 0
    except Error as e:
        print("There was an error with registering.", e)
        return 1


def login_db(cursor, email, password):
    query = f'''SELECT u.id, u.first_name, u.last_name, u.user_name, u.email, u.user_password, u.score 
                FROM Users as u
                WHERE email='{email}' 
                    AND user_password ='{password}' '''
    try:
        cursor.execute(query)
        return cursor.fetchall()
    except Error as e:
        print("There was wn error with fetching the tips.", e)


def get_my_cart_products_db(cursor, email):
    query = f'''   SELECT U.*, T.*, P1.common_name AS 'offered plant', p2.common_name AS 'requested plant', U2.email as 'publisher email', ci.city_name
                    FROM
                        cart AS C,
                        plants AS p1,
                        plants AS p2,
                        users AS U,
                        users as U2,
                        trade_center AS T,
                        Cities as ci
                    WHERE
                        C.user_id = U.id AND T.id = C.trade_id
                            AND p1.id = T.plant_id
                            AND p2.id = T.requested_plant_id
                            AND U.email = '{email}' 
                            AND U2.ID = T.user_id
                            AND ci.ID = t.city_id; '''
    try:
        cursor.execute(query)
        return cursor.fetchall()
    except Error as e:
        print("There was wn error getting cart.", e)


def get_my_offers_products_db(cursor, email):
    query = f'''    SELECT  U1.*, T.*, P1.*, U2.email as reciever_email, ci.city_name , P2.common_name
                    FROM Users as U1
                    JOIN Trade_center as T ON T.user_id = U1.id
                    LEFT JOIN Plants as P1 ON P1.id = T.plant_id
                    LEFT JOIN Plants as P2 ON P2.id = T.requested_plant_id
                    LEFT JOIN Cart as C ON  C.trade_id = T.ID
                    LEFT JOIN Users as U2 ON C.user_id = U2.ID
                    LEFT JOIN Cities as Ci ON Ci.id = T.city_id
                    WHERE U1.email = '{email}';  '''
    try:
        cursor.execute(query)
        return cursor.fetchall()
    except Error as e:
        print("There was wn error with fetching the tips.", e)


def trade_offer_db(cursor, conn, user_id, plant_to_offer, plant_I_want, imageURL,city):
    query = f'''    INSERT INTO Trade_center(user_id ,plant_id ,requested_plant_id ,release_date ,imgUrl,city_id)
                    VALUES( (SELECT id from Users where ID = '{user_id}' limit 1),
                            (SELECT id from Plants where common_name = '{plant_to_offer}' limit 1),
                            (SELECT id from Plants where common_name = '{plant_I_want}' limit 1),
                            DATE(NOW()),
                            '{imageURL}',
                            (SELECT id from Cities where city_name = '{city}' limit 1));
     '''
    try:
        cursor.execute(query)
        conn.commit()
    except Error as e:
        print("There was wn error with adding a new offer.", e)


############################################################
######################## DB pars ########################
############################################################

########### DONE ###############

def get_all_plant_conditions_parse(res):
    """
    "plantName": "Cactus",
        "hoursOfLight": 8,
        "waterFrequency": 7,
        "temperature": 30
        [('Bamboo', Decimal('5.0909'), Decimal('6.0909'), Decimal('21.6364'))
        """
    # print("\n\n",res)
    l = []
    key = {"plantName": "", \
           "hoursOfLight": "", \
           "waterFrequency": "", \
           "temperature": ""}
    # print(type(res[0][1]))

    for i in range(len(res)):
        t = key.copy()
        t["plantName"] = res[i][0]
        t["hoursOfLight"] = round(float(res[i][1]))
        t["waterFrequency"] = round(float(res[i][2]))
        t["temperature"] = round(float(res[i][3]))
        l.append(t)
    return l


def get_all_products_parse(res):
    """
    res is:
    T.ID, P1.id, P1.common_name,p2.common_name,T.release_date,T.imgUrl, T.status_
    ID-0
    plant_id-1
    plant name-2
    request_plant_name-3
    release_date-4
    imgURL-5
    status-6
    """
    # print("\n\n\n",res)
    # [(1, 2, 'Bonsai', 'Wandering Jew', datetime.date(2022, 5, 19), '/assets/chamomile.png'), (2, 1, 'Bamboo', 'Bamboo', datetime.date(2022, 5, 19), '/assets/cactus.png')]
    l = []
    key = {"tradeId": "", \
           "plantId": "", \
           "plantName": "", \
           "requestedPlant": "", \
           "releaseDate": "", \
           "imageUrl": "", \
           "status": "",\
           "city" :""}
    date_str = "T10:00:00.782Z"
    for i in range(len(res)):
        t = key.copy()
        t["tradeId"] = res[i][0]
        t["plantId"] = res[i][1]
        t["plantName"] = res[i][2]
        t["requestedPlant"] = res[i][3]
        t["releaseDate"] = str(res[i][4]) + date_str
        t["imageUrl"] = res[i][5]  # .decode('utf-8')
        t["status"] = "pending"
        t["city"] = res[i][6]
        l.append(t)

    return l


def get_all_plants_parse(res):
    l = []
    key = {"plantId": "", \
           "plantName": ""}
    for i in range(len(res)):
        t = key.copy()
        t["plantId"] = res[i][0]
        t["plantName"] = res[i][1]
        l.append(t)
    return l


def login_parse(res):
    """
    {
    "id": 1,
    "firstName": "Nevo",
    "lastName": "Chen",
    "userName": "nevochen1",
    "email": "nevochen@gmail.com",
    "password": "Aa1234",
    "token": "fake-token",
    "score": 0
}
    """
    # ret[(26, 'Lipaz', 'Horowitz', 'LiHor', 'LiHor@hotmail.com', 'xkgpfmmXOh', 0)]
    l = []
    key = {"id": "", \
           "firstName": "", \
           "lastName": "", \
           "userName": "", \
           "email": "", \
           "password": "", \
           "token": "", \
           "score": ""}
    if(res==[]):
        t = key.copy()
        t["id"] = ""
        t["firstName"] = ""
        t["lastName"] = ""
        t["userName"] = "false"
        t["email"] = ""
        t["password"] = ""
        t["token"] = ""
        t["score"] = ""
        l.append(t)
        return l

    for i in range(len(res)):
        if res[i][0] == "None":
            res[i][6] = 0
        t = key.copy()
        t["id"] = res[i][0]
        t["firstName"] = res[i][1]
        t["lastName"] = res[i][2]
        t["userName"] = res[i][3]
        t["email"] = res[i][4]
        t["password"] = str(res[i][5])
        t["token"] = res[i][0]
        t["score"] = res[i][6]
        l.append(t)

    return l


def get_my_cart_products_parse(res):
    """
    {
    "tradeId": 22,
    "plantId": 2,
    "plantName": "Chamomile",
    "requestedPlant": "Verbena",
    "releaseDate":"2021-01-02T09:00:00.782Z",
    "description": "this is Chamomile",
    "imageUrl": "",
    "status": "pending"
    "publisher" :
    "receiver"
  },
    """
    """
    [(53, 'k', 's', 'sk', 's@k', '123123', 20, 2, 2, 28, 1, datetime.date(2022, 6, 6), '/assets/cactus.png', 'taken', 4, 'Moon Cactus', 'Bamboo', 'JaGar@mail.tau.ac.il'), (53, 'k', 's', 'sk', 's@k', '123123', 20, 4, 2, 70, 15, datetime.date(2022, 6, 6), '/assets/mint.jpg', 'taken', 8, 'Mint', 'Jade Vine', 'JaGar@mail.tau.ac.il'), (53, 'k', 's', 'sk', 's@k', '123123', 20, 7, 53, 67, 26, datetime.date(2022, 6, 6), '/assets/chamomile.png', 'taken', 2, 'Dill', 'Saguaro Cactus', 's@k'), (53, 'k', 's', 'sk', 's@k', '123123', 20, 1, 1, 63, 30, datetime.date(2022, 6, 6), '/assets/lavender.png', 'taken', 2, 'Lavender', 'Queen of the Night', 'LeKan@walla.co.il')]
    [(5, userid-0

     'Abramson'-1, 
     'James',-2
      'JaAbr', -3
     'JaAbr@mymail.com',-4
      'UendyrTDXV',-5
       0,-score-6
        1, - trade_id - 7
        1, - userid who put it in trade center- 8
        2, plant id in trade center-9
        3, plantid that was requested - 10
        datetime.date(2022, 5, 22) - 11
        '/assets/chamomile.png', - 12
        'pendenig', -13
        2, -plant id name-14
        'Bonsai')] - common name - 15
        publisher_email - 16
    """
    l = []
    #print((res[0]))
    key = {"tradeId": "", \
           "plantId": "-", \
           "plantId": "", \
           "plantName": "", \
           "requestedPlant": "", \
           "releaseDate": "", \
           "description": "", \
           "imageUrl": "", \
           "status": "", \
           "publisher": "", \
           "receiver": "", \
           "city":""}

    date_str = "T10:00:00.782Z"
    for i in range(len(res)):
        t = key.copy()
        t["tradeId"] = res[i][7]
        t["plantId"] = res[i][14]
        t["plantName"] = res[i][15]
        t["requestedPlant"] = res[i][16]
        t["releaseDate"] = str(res[i][11]) + date_str
        t["imageUrl"] = res[i][12]  # .decode('utf-8')
        t["status"] = res[i][13]
        t["publisher"] = res[i][17]
        t["receiver"] = res[i][4]
        t["city"] = res[i][18]


        l.append(t)
    return l

def leader_board_parse(res):
    """
    {
    "id": 1,
    "firstName": "Nevo",
    "lastName": "Chen",
    "userName": "nevochen1",
    "email": "nevochen@gmail.com",
    "password": "Aa1234",
    "token": "fake-token",
    "score": 0
    "rank" :0
}
    """
    # ret[(26, 'Lipaz', 'Horowitz', 'LiHor', 'LiHor@hotmail.com', 'xkgpfmmXOh', 0)]
    l = []
    key = {"id": "", \
           "firstName": "", \
           "lastName": "", \
           "userName": "", \
           "email": "", \
           "password": "", \
           "token": "", \
           "score": "",\
           "rank":""}

    for i in range(len(res)):
        if res[i][0] == "None":
            res[i][6] = 0
        t = key.copy()
        t["id"] = res[i][0]
        t["firstName"] = res[i][1]
        t["lastName"] = res[i][2]
        t["userName"] = res[i][3]
        t["email"] = res[i][4]
        t["password"] = hash(str(res[i][5]))
        t["token"] = res[i][0]
        t["score"] = res[i][6]
        t["rank"] = i+1
        l.append(t)

    return l

def get_my_offers_products_parse(res):
    # [(5, 'Abramson', 'James', 'JaAbr', 'JaAbr@mymail.com', 'UendyrTDXV', 5, 5, 5, 3, 46, datetime.date(2022, 5, 23), 'D:studiesangular1plant project1srcassets\x08asil.png', 'taken', 3, 'Wandering Jew'), (5, 'Abramson', 'James', 'JaAbr', 'JaAbr@mymail.com', 'UendyrTDXV', 5, 6, 5, 17, 19, datetime.date(2022, 5, 23), 'assetscilantro.png', 'taken', 17, 'Gollum Jade'), (5, 'Abramson', 'James', 'JaAbr', 'JaAbr@mymail.com', 'UendyrTDXV', 5, 7, 5, 42, 67, datetime.date(2022, 5, 23), '/assets/cilantro.png', 'taken', 42, 'Agen Tulip')]
    """
    {
    "tradeId": 22,
    "plantId": 2,
    "plantName": "Chamomile",
    "requestedPlant": "Verbena",
    "releaseDate":"2021-01-02T09:00:00.782Z",
    "description": "this is Chamomile",
    "imageUrl": "",
    "status": "pending"
    "publisher" :""
    "receiver":
  },
    """
    """
    (53, 'k', 's', 'sk', 's@k', '123123', 20, 7, 53, 67, 26, datetime.date(2022, 6, 6), '/assets/chamomile.png', 'taken', 2, 67, 'Dill', 's@k', 'Afula')
    [(5, userid-0

     'Abramson'-1, 
     'James',-2
      'JaAbr', -3
     'JaAbr@mymail.com',-4
      'UendyrTDXV',-5
       0,-score-6
        1, - trade_id - 7
        1, - userid who put it in trade center- 8
        2, plant id in trade center-9
        3, plantid that was requested - 10
        datetime.date(2022, 5, 22) - 11
        '/assets/chamomile.png', - 12
        'pendenig', -13
        2, -plant id name-14
        'Bonsai')] - common name - 15
        receiver_email-16
    """
    l = []
    key = {"tradeId": "", \
           "plantId": "-", \
           "plantId": "", \
           "plantName": "", \
           "requestedPlant": "", \
           "releaseDate": "", \
           "description": "", \
           "imageUrl": "", \
           "status": "", \
           "publisher": "", \
           "receiver": ""}

    date_str = "T10:00:00.782Z"
    for i in range(len(res)):
        t = key.copy()
        t["tradeId"] = res[i][7]
        t["plantId"] = res[i][14]
        t["plantName"] = res[i][16]
        t["requestedPlant"] = res[i][19]
        t["releaseDate"] = str(res[i][11]) + date_str
        t["imageUrl"] = res[i][12]  # .decode('utf-8')
        t["status"] = res[i][13]
        t["publisher"] = res[i][4]
        t["receiver"] = res[i][17]
        l.append(t)
    return l


def get_cities_parse(res):
    """
        {"City":"Acre"},

    """
    #[('Acre',), ('Afula',), ('Arad',), ('Ariel',), ('Ashdod',), ('Ashkelon',), ('Baqa-Jatt',), ('BatYam',), ('Beersheba',), ("BeitShe'an",), ('BeitShemesh',), ('BeitarIllit',), ('BneiBrak',), ('Dimona',), ('Eilat',), ("El'ad",), ("Giv'atayim",), ("Giv'atShmuel",), ('Hadera',), ('Haifa',), ('Herzliya',), ('HodHaSharon',), ('Holon',), ('Jerusalem',), ('Karmiel',), ('KafrQasim',), ('KfarSaba',), ('KiryatAta',), ('KiryatBialik',), ('KiryatGat',), ('KiryatMalakhi',), ('KiryatMotzkin',), ('KiryatOno',), ('KiryatShmona',), ('KiryatYam',), ('Lod',), ("Ma'aleAdumim",), ("Ma'alot-Tarshiha",), ('MigdalHaEmek',), ("Modi'inIllit",), ("Modi'in-Maccabim-Re'ut",), ('Nahariya',), ('Nazareth',), ('NazarethIllit',), ('Nesher',), ('NessZiona',), ('Netanya',), ('Netivot',), ('Ofakim',), ('OrAkiva',), ('OrYehuda',), ('PetahTikva',), ('Qalansawe',), ("Ra'anana",), ('Rahat',), ('RamatGan',), ('RamatHaSharon',), ('Ramla',), ('Rehovot',), ('RishonLeZion',), ('RoshHaAyin',), ('Safed',)]
    l = []
    key = {"City":""}

    for i in range(len(res)):
        t = key.copy()
        t["City"] = res[i][0]
        l.append(t)
    return l


########### TBD ###############


def register_parse(res):
    pass


def trade_offer_parse(ret):
    pass


# don't know what needs to be returned
def how_to_treat_parse(ret):
    pass


#########################################################
######################## routing ########################
#########################################################

################ user-services ################


# works
'''
@app.route("/profileurl", methods=['GET'])
def profile():
    cursor, con = conne()
    ret = profile_db(cursor)
    close_connection(cursor)
    return jsonify(ret)
'''
#leader board
@app.route("/getLeaderboard", methods=['GET'])
def get_leader_board():
    cursor,con = conne()
    ret = leader_board_db(cursor,10)
    ret=leader_board_parse(ret)
    close_connection(cursor)
    return jsonify(ret)

# register - works
@app.route("/users/register", methods=['POST'])
def register():
    # {'id': 0, 'firstName': 'first', 'lastName': 'last', 'userName': 'user', 'email': 'a@a', 'password': '123123', 'token': 'token', 'score': 0}
    data = request.get_data()
    data = data.decode('utf-8')
    data = json.loads(data)
    email = data['email']
    password = data['password']
    first_name = data['firstName']
    last_name = data['lastName']
    cursor, con = conne()
    #id_number = uuid.uuid1()
    # def register_db(cursor, id_number, last_name, first_name, email, user_pass, score):
    username = data['userName']
    ret = register_db(cursor, con, username, last_name, first_name, email, password, 0)
    #ret = login_db(cursor, email, password)
    #ret = login_parse(ret)
    close_connection(cursor)
    if(ret==1):
        ret=login_parse("")
        return jsonify(ret[0])

    return jsonify("0")


# login - parsed 
@app.route("/users/authenticate", methods=['POST'])  # Send in 'Post' method: username, password
def login():
    data = request.get_data()
    data = data.decode('utf-8')
    data = json.loads(data)
    email = data['email']
    password = data['password']
    cursor, con = conne()
    ret = login_db(cursor, email, password)
    ret = login_parse(ret)
    close_connection(cursor)
    return jsonify(ret[0])


################ trade-services ################
# trade center
# works
@app.route("/getAllProducts", methods=['GET'])
def get_all_products():
    cursor, con = conne()
    ret = get_all_products_db(cursor)
    close_connection(cursor)
    ret = get_all_products_parse(ret)
    #    f = open("getAllProducts.json", "w")
    #    print(json.dumps(ret))
    #    f.write((json.dumps(ret)))
    #    f.close()
    return jsonify(ret)


# works
@app.route("/getMyCartProducts", methods=['POST'])
def get_my_cart_products():
    data = request.get_data()
    data = data.decode('utf-8')
    data = json.loads(data)
    email = data['email']
    cursor, con = conne()
    ret = get_my_cart_products_db(cursor, email)
    ret = get_my_cart_products_parse(ret)
    close_connection(cursor)
    # ret=get_all_products_parse(ret)
    return jsonify(ret)


# works
@app.route("/getMyOffersProducts", methods=['POST'])
def get_my_offers_products():
    data = request.get_data()
    data = data.decode('utf-8')
    data = json.loads(data)
    # {'email': 'JaAbr@mymail.com', 'firstName': 'James', 'id': 5, 'lastName': 'Abramson', 'password': 4438525316096552400, 'score': 0, 'token': 5, 'userName': 'JaAbr'}
    email = data['email']
    cursor, con = conne()
    ret = get_my_offers_products_db(cursor, email)
    # print("\n\n\n",ret)
    ret = get_my_offers_products_parse(ret)
    close_connection(cursor)
    return jsonify(ret)


@app.route("/addToCart", methods=['POST'])
def add_trade():
    data = request.get_data()
    data = data.decode('utf-8')
    data = json.loads(data)
    # b'{"userId":5,"tradeId":6}'
    userId = str(data['userId'])
    tradeId = data['tradeId']
    # print("\n\n\n",type(userId),type(tradeId))
    cursor, con = conne()
    ret = ""
    # add_to_cart_db(cursor, conn, user_id, trade_id)
    ret = add_to_cart_db(cursor, con, userId, tradeId)
    close_connection(cursor)
    return jsonify(ret)


@app.route("/getCities", methods=['GET'])
def get_cities():
    cursor, con = conne()
    ret = get_cities_db(cursor)
    ret=get_cities_parse(ret)
    close_connection(cursor)
    return jsonify(ret)


# works
@app.route("/tradeOffer", methods=['POST'])
# adding a plant to the trade center
def trade_offer():
    # URL = "D:\\studies\\angular1\\plant project1\\src\\assets\\"
    URL = "/assets/"
    a = "fakepath"

    data = request.get_data()
    data = data.decode('utf-8')
    data = json.loads(data)
    # {'plant': 'Dill', 'desiredPlant': 'Gollum Jade', 'image': 'C:\\fakepath\\fennel.png'}
    cursor, con = conne()
    # trade_offer_db(cursor,con, user_id, plant_to_offer, plant_I_want, imageURL)
    userId = data['userId']
    plant = data['plant']
    city= data['city']
    desiredPlant = data['desiredPlant']
    plant = data['plant']
    d = data['image'].rfind("\\")
    if a in data['image']:
        image= data['image']
    else:
        image = URL + data['image'][(d + 1):]
    ret = trade_offer_db(cursor, con, userId, plant, desiredPlant, image,city)
    # ret=trade_offer_parse(ret)
    close_connection(cursor)
    return jsonify(ret)


################ how-to-treat-services ################
# works
@app.route("/getPlantsTreatConditions", methods=['GET'])
def get_all_plant_conditions():
    """
    cursor,con = conne()
    ret = get_all_plant_conditions_db(cursor, plant_name)
    close_connection(cursor)
    return jsonify(ret)
    """
    cursor, con = conne()
    ret = get_all_plant_conditions_db(cursor)
    close_connection(cursor)
    ret = get_all_plant_conditions_parse(ret)
    return jsonify(ret)


# works
@app.route("/getAllPlants", methods=['GET'])
def get_all_plants():
    cursor, con = conne()
    ret = get_all_plants_db(cursor)
    close_connection(cursor)
    ret = get_all_plants_parse(ret)
    return jsonify(ret)


# works
# contribute Knowledge
@app.route("/contribute", methods=['POST'])  # Send in 'Post' method: 'contribute' object
def how_to_treat():
    data = request.get_data()
    data = data.decode('utf-8')
    data = json.loads(data)
    # {'contribute': {'userId': 1, 'plantName': 'Parsly', 'light': 4, 'water': 7, 'temp': 4}}
    """ export class NewOffer {
    userId!: number;
    plant!: string;
    desiredPlant!: string;
    image!: File;

 """
    userid = data['userId']
    plant_name = data['plantName']
    light = data['light']
    temp = data['temp']
    water = data['water']
    cursor, con = conne()
    ret = how_to_treat_db(cursor, con, plant_name, light, temp, water, userid)
    # ret = how_to_treat_parse(ret)
    close_connection(cursor)
    return jsonify(ret)


#####################################################
######################## RUN ########################
#####################################################


app.run(host="localhost", port=8000, debug=True)
