import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MessageService } from 'primeng/api';
import { AuthenticationService } from 'src/app/services/AuthenticationService';
import { TradeService } from 'src/app/services/trade-service';
import { BaseItemComponent } from '../base-item/base-item.component';

@Component({
  selector: 'app-grid-item',
  templateUrl: './grid-item.component.html',
  styleUrls: ['./grid-item.component.scss']
})

export class GridItemComponent extends BaseItemComponent implements OnInit {

  constructor(tradeService: TradeService, router: Router,  authService: AuthenticationService, messageService: MessageService) {
    super(tradeService, router, authService, messageService);
  }
}
