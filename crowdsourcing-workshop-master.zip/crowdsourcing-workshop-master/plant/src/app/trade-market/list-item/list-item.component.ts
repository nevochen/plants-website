import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MessageService } from 'primeng/api';
import { TradeRequest } from 'src/app/models/TradeRequest';
import { AuthenticationService } from 'src/app/services/AuthenticationService';
import { TradeService } from 'src/app/services/trade-service';
import { BaseItemComponent } from '../base-item/base-item.component';

@Component({
  selector: 'app-list-item',
  templateUrl: './list-item.component.html',
  styleUrls: ['./list-item.component.scss']
})
export class ListItemComponent extends BaseItemComponent implements OnInit  {
  
  constructor(tradeService: TradeService, router: Router,  authService: AuthenticationService, messageService: MessageService) {
    super(tradeService, router, authService, messageService);
  }

}
