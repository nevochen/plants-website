import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MessageService } from 'primeng/api';
import { Subscription } from 'rxjs';
import { TradeRequest } from 'src/app/models/TradeRequest';
import { User } from 'src/app/models/User';
import { AuthenticationService } from 'src/app/services/AuthenticationService';
import { TradeService } from 'src/app/services/trade-service';

@Component({
  selector: 'app-base-item',
  template: `<div></div>`,
  providers:[TradeService]
})
export class BaseItemComponent implements OnInit {
  @Input() product!: TradeRequest;
  public currentUser!: User | null;
  private subscriptions: Subscription = new Subscription();
  
  constructor(private tradeService: TradeService, private router: Router, private authService: AuthenticationService, private messageService: MessageService) {

  }

  ngOnInit(): void {
    this.authService.currentUser.subscribe(user=> {
      if (this.authService.isNotEmpty() && user){
        this.currentUser = user;
      } else {
        this.currentUser = null;
      }
    });

  }

  ngOnDestroy(): void {
    this.subscriptions.unsubscribe();
  }

  public addToCart(product : TradeRequest): void {
    if(this.currentUser){
      this.subscriptions.add(this.tradeService.addToCart(this.currentUser.id, product.tradeId).subscribe());
      this.messageService.add({ key: 'addToCart', severity: 'success', summary: 'Success', detail: 'Added to cart' });
      location.reload();
    }
    else{
      this.router.navigate(['/login']);
    }
  }

}
