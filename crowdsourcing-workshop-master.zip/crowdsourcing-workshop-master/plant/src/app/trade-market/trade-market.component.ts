import { Component, OnDestroy, OnInit } from '@angular/core';
import { MessageService, SelectItem } from "primeng/api";
import { PrimeNGConfig } from "primeng/api";
import { ButtonModule } from 'primeng/button';
import { TradeService } from '../services/trade-service';
import { TradeRequest } from '../models/TradeRequest';
import { ActivatedRoute, Router } from '@angular/router';
import { User } from '../models/User';
import { AuthenticationService } from '../services/AuthenticationService';
import { Subscription } from 'rxjs';
import { dashCaseToCamelCase } from '@angular/compiler/src/util';

@Component({
  templateUrl: './trade-market.component.html',
  styleUrls: ['./trade-market.component.scss'],
  providers: [TradeService, MessageService]
})
export class TradeMarketComponent implements OnInit, OnDestroy {
  public currentUser!: User | null;
  public sortField = "";
  public sortOrder = 10;
  public sortOptions: any;
  public products: TradeRequest[] = [];
  public sortKey!: string;
  private subscriptions: Subscription = new Subscription();
  public trade: boolean = false;
  public display!: boolean;

  constructor(private tradeService: TradeService, private router: Router, private authService: AuthenticationService) {
    this.authService.currentUser.subscribe(user=> {
      if (this.authService.isNotEmpty() && user){
        this.currentUser = user;
      } else {
        this.currentUser = null;
      }
    });
  }

  ngOnDestroy(): void {
    this.subscriptions.unsubscribe();
  }

  ngOnInit(): void {
    this.subscriptions.add(this.tradeService.getAllProducts().subscribe(data => {
     this.products = data;
    }));
    this.sortOptions = [
      { label: 'Newest First', value: '!releaseDate' },
      { label: 'Oldest First', value: 'releaseDate' },
      { label: 'Plant Name', value: 'plantName' }
    ];
    
    this.tradeService.display.subscribe(bool => {this.display = bool});
  }

  public onSortChange(event: { value: any; }) {
    let value = event.value;

    if (value.indexOf('!') === 0) {
      this.sortOrder = -1;
      this.sortField = value.substring(1, value.length);
    }
    else {
      this.sortOrder = 1;
      this.sortField = value;
    }
  }

  public myOffers(): void {
    this.router.navigate(['/my_offers']);
  }
  public showDialog() {
    if(!this.currentUser){
      this.router.navigate(['/login']);
    }
    this.tradeService.updateDisplay(true);
  }
}


