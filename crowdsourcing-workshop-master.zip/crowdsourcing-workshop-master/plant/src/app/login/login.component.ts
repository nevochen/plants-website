import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { first, Subscription } from 'rxjs';
import { AuthenticationService } from '../services/AuthenticationService';



@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  private subscription!: Subscription;
  submitted!: boolean;
  loading!: boolean;
  returnUrl!: string;
  errorLogin: boolean = false;

  loginForm = new FormGroup({
    email: new FormControl('', [Validators.required]),
    password: new FormControl('', [Validators.required]),

  });

  constructor(private authenticationService: AuthenticationService
    , private router: Router
  ) { }

  ngOnDestroy(): void {
    if(this.subscription){
      this.subscription.unsubscribe();
    }
  }

  ngOnInit() { }

  onSubmit() {
    this.submitted = true;

    if (this.loginForm.invalid) {
      return;
    }
    this.loading = true;
    this.authenticationService.login(this.loginForm.value.email, this.loginForm.value.password)
      .pipe(first())
      .subscribe({
        next: (data) => {
                if(data.userName =="false"){
                  this.loginForm.reset();
                  this.errorLogin = true;
                }
                else{
                  this.errorLogin = false;
                  if(this.authenticationService.redirectUrl){
                    this.router.navigateByUrl(this.authenticationService.redirectUrl);
                  }
                  else {
                    this.router.navigate(["/home"]); 
                  }
                }
              },
        error: (error) => {
          this.loading = false;
        }
      });
  }
}
