import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { TradeRequest } from '../models/TradeRequest';
import { User } from '../models/User';
import { AuthenticationService } from '../services/AuthenticationService';
import { TradeService } from '../services/trade-service';

@Component({
  selector: 'app-my-offers',
  templateUrl: './my-offers.component.html',
  styleUrls: ['./my-offers.component.scss']
})
export class MyOffersComponent implements OnInit {
  public products: TradeRequest[] = [];
  private subscriptions: Subscription = new Subscription();
  user!: User;
  public display!: boolean;

  constructor(private router: Router, private tradeService: TradeService, private authenticationService: AuthenticationService) { }

  ngOnInit(): void {
    this.tradeService.updateDisplay(false);
    this.subscriptions.add(this.authenticationService.currentUser.subscribe(user => {
      if(!user){
        this.user = new User('','','','','');
      }
      else{
        this.user = user;
      }
    }));

    this.subscriptions = this.tradeService.getMyOffersProducts(this.user).subscribe(data => {
      this.products = data;
    });

    this.tradeService.display.subscribe(bool => {this.display = bool});
  }

  public showDialog() {
    this.tradeService.updateDisplay(true);
  }

  public onBack() {
    this.router.navigate(['/market']);
  }
}
