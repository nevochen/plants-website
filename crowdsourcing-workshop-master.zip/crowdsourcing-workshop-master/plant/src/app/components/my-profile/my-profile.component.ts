import { Component, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { Rank } from 'src/app/models/Rank';
import { User } from 'src/app/models/User';
import { AuthenticationService } from 'src/app/services/AuthenticationService';
import { UserService } from 'src/app/services/user-service';


@Component({
  templateUrl: './my-profile.component.html' ,
  styleUrls: ['./my-profile.component.scss']
})
export class MyProfileComponent implements OnInit {
  user!: User;
  public users: Rank[] = [];
  private subscriptions: Subscription = new Subscription();
  
  constructor(private authenticationService: AuthenticationService, private userService: UserService) {
  }

  ngOnInit(): void {
    this.subscriptions.add(this.authenticationService.currentUser.subscribe(user => {
      if(!user){
        this.user = new User('','','','','');
      }
      else{
        this.user = user;
      }
    }));

    this.subscriptions = this.userService.getLeaderboard().subscribe(data => {
      this.users = data;
    });
  }
}
