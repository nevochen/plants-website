import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable, of, throwError } from 'rxjs';
import { catchError, every, map, retry } from 'rxjs/operators';

import { MessageService } from 'primeng/api';
import { NewOffer } from '../models/NewOffer';
import { AuthenticationService } from './AuthenticationService';
import { User } from '../models/User';

@Injectable({
  providedIn: 'root'
})
export class TradeService {
  public display: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);
  constructor(private httpClient: HttpClient, private messageService: MessageService, private authenticationService: AuthenticationService) {

  }
  public getAllProducts(): Observable<any> {
    return this.httpClient.get("http://127.0.0.1:8000/getAllProducts");
    //return this.httpClient.get("assets/data/getAllProducts.json");
  }

  public getMyCartProducts(user: User): Observable<any> {
    return this.httpClient.post('http://127.0.0.1:8000/getMyCartProducts', user);
    //return this.httpClient.get("assets/data/getMyCartProducts.json");
  }

  public getMyOffersProducts(user: User): Observable<any> {
    return this.httpClient.post('http://127.0.0.1:8000/getMyOffersProducts', user);
    //return this.httpClient.get("assets/data/getMyOffersProducts.json");
  }

  public addToCart(userId:number, tradeId: number): Observable<any> {
    return this.httpClient.post('http://127.0.0.1:8000/addToCart', {userId, tradeId});
  }

  public postTradeOffer(newOffer: NewOffer): Observable<any>{
    this.display.next(false);
    return this.httpClient.post('http://127.0.0.1:8000/tradeOffer', newOffer);
  }

  public getCities(): Observable<any> {
    return this.httpClient.get("http://127.0.0.1:8000/getCities");
    //return this.httpClient.get("assets/data/cities.json");
  }

  updateDisplay(bool: boolean){
    this.display.next(bool);
  }
}