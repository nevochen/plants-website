import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { User } from '../models/User';

@Injectable({
    providedIn: 'root',
  })
export class UserService {
    constructor(private httpClient: HttpClient) { }

    register(user: User): Observable<any> {
      return this.httpClient.post('http://127.0.0.1:8000/users/register', user);
                //return this.httpClient.get<any>("assets/data/users.json");

    }

    public getLeaderboard(): Observable<any> {
        return this.httpClient.get("http://127.0.0.1:8000/getLeaderboard");
        //return this.httpClient.get("assets/data/getLeaderboard.json");
      }
}