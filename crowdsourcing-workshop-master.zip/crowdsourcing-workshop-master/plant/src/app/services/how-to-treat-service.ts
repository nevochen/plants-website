import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, retry } from 'rxjs/operators';
import { TradeRequest } from '../models/TradeRequest';
import { Contribute } from '../models/Contribute';


@Injectable({
  providedIn: 'root',
})
export class HowToTreatService { 

  constructor(private httpClient: HttpClient) { }
  public getPlantsTreatConditions():Observable<any> {
     return this.httpClient.get("http://127.0.0.1:8000/getPlantsTreatConditions");
    //return this.httpClient.get("assets/data/getPlantsTreatConditions.json");
  }

  public getAllPlants():Observable<any> {
    return this.httpClient.get("http://127.0.0.1:8000/getAllPlants");
    //return this.httpClient.get("assets/data/getAllPlants.json");
}

  public contribute(contribute: Contribute):Observable<any> {
    return this.httpClient.post("http://127.0.0.1:8000/contribute", contribute);
    //return this.httpClient.get("assets/data/getAllPlants.json");
   }
}