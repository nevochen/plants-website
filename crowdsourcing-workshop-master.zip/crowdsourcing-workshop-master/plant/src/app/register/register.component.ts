import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { first, Subscription } from 'rxjs';
import { User } from '../models/User';
import { AuthenticationService } from '../services/AuthenticationService';
import { UserService } from '../services/user-service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss'],
  providers:[UserService]
})
export class RegisterComponent implements OnInit, OnDestroy {
  private subscription!:Subscription;
  public status: boolean = false;
  public errorRegister: boolean = false;
  registerForm = new FormGroup({
    firstName: new FormControl('', [Validators.required]),
    lastName: new FormControl('', [Validators.required]),
    userName: new FormControl('', [Validators.required]),
    email: new FormControl('', [Validators.required, Validators.email]),
    password: new FormControl('',[Validators.required, Validators.minLength(6)])
  });

  constructor(private userService: UserService, private authenticationService: AuthenticationService
    , private router: Router) { }
 

  ngOnInit(): void {

  }

  ngOnDestroy(): void {
    if(this.subscription){
      this.subscription.unsubscribe();
    }
  }

  onSubmit(){
    const firstName = this.registerForm.get('firstName')?.value;
    const lastName = this.registerForm.get('lastName')?.value;
    const userName = this.registerForm.get('userName')?.value;
    const email = this.registerForm.get('email')?.value;
    const password = this.registerForm.get('password')?.value;
    const user = new User(firstName, lastName, userName, email, password);
    this.userService.register(user)
    .pipe(first())
    .subscribe({
      next: (data) => {
        if(data.userName =="false"){
          this.registerForm.reset();
          this.errorRegister = true;
        }
        else{
            this.errorRegister = false;
            if(data){
              this.status = true;
              if(this.authenticationService.redirectUrl){
                this.router.navigateByUrl(this.authenticationService.redirectUrl);
              }
              else {
                this.router.navigate(["/home"]); 
              }
            }
            else {
              this.status = false;
            }
        }
      },
      error: (error) => {
        this.status = false;
      }
    }
    );
  }

}
