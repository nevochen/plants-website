import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MyProfileComponent } from './components/my-profile/my-profile.component';
import { InputTextModule } from "primeng/inputtext";
import { RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { PlantsPanelComponent } from './plants-panel/plants-panel.component';
import {MenubarModule} from 'primeng/menubar';
import {TabViewModule} from 'primeng/tabview';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {ButtonModule} from 'primeng/button';
import { TradeMarketComponent } from './trade-market/trade-market.component';
import {CardModule} from 'primeng/card';
import { HttpClientModule } from "@angular/common/http";
import { HowToTreatComponent } from './how-to-treat/how-to-treat.component';
import { TradeService } from './services/trade-service';
import {AutoCompleteModule} from 'primeng/autocomplete';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {DialogModule} from 'primeng/dialog';
import {SliderModule} from 'primeng/slider';
import { ContributeKnowledgeComponent } from './contribute-knowledge/contribute-knowledge.component';
import { SearchPlantComponent } from './search-plant/search-plant.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { UserService } from './services/user-service';
import { MyCartComponent } from './my-cart/my-cart.component'; // not declared in this module. required for navigation.
import { MyOffersComponent } from './my-offers/my-offers.component'; // not declared in this module. required for navigation.
import { NewOfferComponent } from './new-offer/new-offer.component';
import {FileUploadModule } from 'primeng/fileupload';
import { AuthenticationService } from './services/AuthenticationService';
import { AuthGuardGuard } from './auth-guard.guard';
import { TreatCardComponent } from './how-to-treat/treat-card/treat-card.component';
import { ListItemComponent } from './trade-market/list-item/list-item.component';
import { BaseItemComponent } from './trade-market/base-item/base-item.component';
import { GridItemComponent } from './trade-market/grid-item/grid-item.component';

import {DataViewModule} from 'primeng/dataview';
import {DropdownModule} from 'primeng/dropdown';
import {ToastModule} from 'primeng/toast';
import { MessageService } from 'primeng/api';
import {TableModule} from 'primeng/table';
import { Message } from '@angular/compiler/src/i18n/i18n_ast';

@NgModule({
  declarations: [
    AppComponent,
    MyProfileComponent,
    HomeComponent,
    PlantsPanelComponent,
    HowToTreatComponent,
    ContributeKnowledgeComponent,
    SearchPlantComponent,
    LoginComponent,
    RegisterComponent,
    TreatCardComponent,
    MyCartComponent,
    MyOffersComponent,
    TradeMarketComponent,
    ListItemComponent,
    BaseItemComponent,
    NewOfferComponent,
    GridItemComponent
  ],
  imports: [
    FileUploadModule,
    ReactiveFormsModule,
    SliderModule,
    DialogModule,
    BrowserModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    InputTextModule,
    MenubarModule,
    ButtonModule,
    TabViewModule,
    FormsModule,
    AutoCompleteModule,
    CardModule,
    HttpClientModule,
    TableModule,
    DialogModule,
    BrowserModule,
    BrowserAnimationsModule,
    DataViewModule,
    AutoCompleteModule,
    ButtonModule,
    DropdownModule,
    InputTextModule,
    FormsModule,
    ToastModule,
    RouterModule.forRoot([
      {path: 'home', component: HomeComponent },
      {path: 'profile', canActivate:[AuthGuardGuard], component: MyProfileComponent } ,
      {path: 'market', component: TradeMarketComponent } ,
      {path: 'how_to_treat', component: HowToTreatComponent } ,
      {path: 'contribute_knowledge', canActivate:[AuthGuardGuard], component: ContributeKnowledgeComponent } ,
      {path: 'login', component: LoginComponent },
      {path: 'register', component: RegisterComponent },
      {path: 'my_cart', canActivate:[AuthGuardGuard], component: MyCartComponent },
      {path: 'my_offers', canActivate:[AuthGuardGuard], component: MyOffersComponent },
      {path: 'new_offer', canActivate:[AuthGuardGuard], component: NewOfferComponent },
      {path: '', redirectTo: 'market', pathMatch: 'full' }
    ])
  ],
  providers: [TradeService, UserService, MessageService],
  bootstrap: [AppComponent],
  entryComponents: [MyProfileComponent, PlantsPanelComponent]
})
export class AppModule { }
