import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ContributeKnowledgeComponent } from './contribute-knowledge.component';

describe('ContributeKnowledgeComponent', () => {
  let component: ContributeKnowledgeComponent;
  let fixture: ComponentFixture<ContributeKnowledgeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ContributeKnowledgeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ContributeKnowledgeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
