import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Subscription } from 'rxjs';
import { Contribute } from '../models/Contribute';
import { User } from '../models/User';
import { SearchPlantComponent } from '../search-plant/search-plant.component';
import { AuthenticationService } from '../services/AuthenticationService';
import { HowToTreatService } from '../services/how-to-treat-service';
import { UserService } from '../services/user-service';


@Component({
  selector: 'app-contribute-knowledge',
  templateUrl: './contribute-knowledge.component.html',
  styleUrls: ['./contribute-knowledge.component.scss']
})
export class ContributeKnowledgeComponent extends SearchPlantComponent implements OnInit, OnDestroy {
  public plantName!: string;
  public light!: number;
  public water!: number;
  public temp!: number;
  user!: any;

  contributeForm = new FormGroup({
    plantName: new FormControl('', [Validators.required]),
    light: new FormControl('', [Validators.required]),
    water: new FormControl('', [Validators.required]),
    temp: new FormControl('', [Validators.required])
  });

  constructor(howToTreatService: HowToTreatService, private authenticationService: AuthenticationService, private userService: UserService) {
    super(howToTreatService);
  }

  override ngOnInit(): void {
    this.subscriptions.add(this.howToTreatService.getAllPlants().subscribe(data => {this.results = data;})
    )
    this.subscriptions.add(this.howToTreatService.getPlantsTreatConditions().subscribe(data => {this.resultsInfo = data;})
    )
    this.subscriptions.add(this.authenticationService.currentUser.subscribe(user => {
      this.user = user;
      if(!user){
        this.user = new User('','','','','');
      }
      else{
        this.user = user;
      }
    }));
  }

  onSubmit(){
    const userId = this.user.id;
    const plantName = this.contributeForm.get('plantName')?.value;
    const light = this.contributeForm.get('light')?.value;
    const water = this.contributeForm.get('water')?.value;
    const temp = this.contributeForm.get('temp')?.value;
    const contribute = new Contribute(userId, plantName, light, water, temp);
    this.subscriptions.add(this.howToTreatService.contribute(contribute).subscribe());
    this.userService.getLeaderboard().subscribe(); // To refresh leaderboard
  }
}
