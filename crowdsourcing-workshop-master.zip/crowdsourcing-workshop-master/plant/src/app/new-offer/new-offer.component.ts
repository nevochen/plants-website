import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { MessageService } from 'primeng/api';
import { first, Subscription } from 'rxjs';
import { NewOffer } from '../models/NewOffer';
import { User } from '../models/User';
import { SearchPlantComponent } from '../search-plant/search-plant.component';
import { AuthenticationService } from '../services/AuthenticationService';
import { HowToTreatService } from '../services/how-to-treat-service';
import { TradeService } from '../services/trade-service';
import { TradeMarketComponent } from '../trade-market/trade-market.component';

@Component({
  selector: 'app-new-offer',
  templateUrl: './new-offer.component.html',
  styleUrls: ['./new-offer.component.scss']
})
export class NewOfferComponent extends SearchPlantComponent implements OnInit {
  public plantName!: string;
  public desiredPlant: any;
  public image!: File;
  public user!: any;
  public selectedCity!: string;
  public cities!: any[];
  
  offerForm = new FormGroup({
    plant: new FormControl('', [Validators.required]),
    desiredPlant: new FormControl('', [Validators.required]),
    city: new FormControl('', [Validators.required]),
    image: new FormControl(null, [Validators.required]) 
  });
  
  constructor(howToTreatService: HowToTreatService, private TradeMarketService: TradeService, private router: Router, private messageService: MessageService, private authenticationService: AuthenticationService) {
    super(howToTreatService);
   }

  override ngOnInit(): void {
    this.subscriptions.add(this.howToTreatService.getAllPlants().subscribe(data => {this.results = data;})
    )
    this.subscriptions.add(this.howToTreatService.getPlantsTreatConditions().subscribe(data => {this.resultsInfo = data;})
    )
    this.subscriptions.add(this.authenticationService.currentUser.subscribe(user => {
      this.user = user;
      if(!user){
        this.user = new User('','','','','');
      }
      else{
        this.user = user;
      }
    }));
    this.subscriptions.add(this.TradeMarketService.getCities().subscribe(data => {this.cities = data;}));
  }

  public onSelectOffer(event:any){
    this.selectedPlant = this.results.find((x:any)=> x.plantName == event);
  }

  public onSelectDesired(event:any){
    this.desiredPlant = this.results.find((x:any)=> x.plantName == event);
  }

  onSubmit(): void {
    const userId = this.user.id;
    const plant = this.offerForm.get('plant')?.value;
    const desiredPlant = this.offerForm.get('desiredPlant')?.value;
    const city = this.offerForm.get('city')?.value.City;
    const image = this.offerForm.get('image')?.value;
    const newOffer = new NewOffer(userId, plant, desiredPlant, city, image);
    this.TradeMarketService.postTradeOffer(newOffer).subscribe();
    this.messageService.add({ key: 'addToCart', severity: 'success', summary: 'Success', detail: 'Offer uploaded' });
    this.offerForm.reset();
    location.reload();
  }

  onFileSelected(event:any) {
    this.image = event.target.files[0]; 
  }
}
