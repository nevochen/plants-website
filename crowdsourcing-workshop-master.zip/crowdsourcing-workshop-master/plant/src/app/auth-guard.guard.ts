import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import { User } from './models/User';
import { AuthenticationService } from './services/AuthenticationService';

@Injectable({
  providedIn: 'root'
})

export class AuthGuardGuard implements CanActivate {
  public currentUser !: User|null;
  constructor(private authService: AuthenticationService, 
              private router: Router){
                this.authService.currentUser.subscribe(user=> {
                  if (this.authService.isNotEmpty() && user ){
                    this.currentUser = user;
                  } else {
                    this.currentUser = null;
                  }
                });
              }
  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): boolean {
    return this.checkLoggedIn(state.url);
  }

  checkLoggedIn(url: string): boolean {
    if(this.currentUser && this.currentUser.userName != "false") {
      return true;
    }
    this.authService.redirectUrl = url;
    this.router.navigate(['/login']);
    return false;
  }
  
}
