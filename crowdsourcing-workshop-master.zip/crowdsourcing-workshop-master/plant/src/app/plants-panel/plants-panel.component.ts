import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {MenuItem, PrimeIcons} from 'primeng/api';
import { User } from '../models/User';
import { AuthenticationService } from '../services/AuthenticationService';

@Component({
  selector: 'app-plants-panel',
  templateUrl: './plants-panel.component.html',
  styleUrls: ['./plants-panel.component.scss']
})
export class PlantsPanelComponent implements OnInit {
  public items: MenuItem[] = [];
  public currentUser!: User | null;
  constructor(private router: Router, private authService: AuthenticationService) {
    this.authService.currentUser.subscribe(user=> {
      if (this.authService.isNotEmpty() && user){
        this.currentUser = user;
      } else {
        this.currentUser = null;
      }
    });
   }

  ngOnInit(): void {
    this.items = [
      {
          label: 'My Account',
          icon: 'pi pi-fw pi-user',
          routerLink:['/profile']
      },
      {
        label: 'Trade Center',
        icon: 'pi pi-fw pi-shopping-bag',
        routerLink:['/market']
    },
    {
      label: 'About Plants',
      icon: 'pi pi-fw pi-align-justify',
      items: [
        {label: 'Grow my plant' , icon: 'pi pi-fw pi-sun', routerLink:['/how_to_treat']},
        {label: 'Contribute knowledge', icon: 'pi pi-info-circle', routerLink:['/contribute_knowledge']} 
      ]
    },
    {
      label: 'My Cart',
      routerLink:['/my_cart']
    }
  ];
  }

  public onLogin() {
    this.router.navigate(['/login']);
  }

  public onLogout() {
    this.authService.logout();
  }

}
