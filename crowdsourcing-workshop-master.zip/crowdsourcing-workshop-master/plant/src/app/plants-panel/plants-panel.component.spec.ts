import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PlantsPanelComponent } from './plants-panel.component';

describe('PlantsPanelComponent', () => {
  let component: PlantsPanelComponent;
  let fixture: ComponentFixture<PlantsPanelComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PlantsPanelComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PlantsPanelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
