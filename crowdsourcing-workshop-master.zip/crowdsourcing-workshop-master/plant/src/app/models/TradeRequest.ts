export class TradeRequest {
    tradeId!: number;
    plantId!: number;
    plantName!: string;
    requestedPlant!: string;
    releaseDate!: Date;
    imageUrl!: string;
    status!: string;
    publisher!: string;
    receiver!: string;
    city!: string;
}

