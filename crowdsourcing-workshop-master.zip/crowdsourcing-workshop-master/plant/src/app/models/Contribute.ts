export class Contribute {
    userId!: number;
    plantName!: string;
    light!: number;
    water!: number;
    temp!: number;

    constructor(userId: number, plantName:string, light:number, water:number, temp:number ){
        this.userId = userId;
        this.plantName = plantName;
        this.light = light;
        this.water = water;
        this.temp = temp;
    }
}