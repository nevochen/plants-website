import { last } from "rxjs";

export class User {
    id!: any;
    firstName!: string;
    lastName!: string;
    userName!: string;
    email!: string;
    password!: string;
    token!: string;
    score!: number;

    constructor(firstName:string, lastName:string, userName:string, email:string, password:string){
        this.id = 0;
        this.firstName = firstName;
        this.lastName = lastName;
        this.userName = userName;
        this.email = email;
        this.password = password;
        this.token = "token";
        this.score = 0;
    }
}