export class Rank {
    id!: any;
    firstName!: string;
    lastName!: string;
    userName!: string;
    email!: string;
    password!: string;
    token!: string;
    score!: number;
    rank!: number;
}