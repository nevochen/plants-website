export class NewOffer {
    userId!: number;
    plant!: string;
    desiredPlant!: string;
    city!: string;
    image!: File;

    constructor(userId: number, plant: string, desiredPlant: string, city: string, image: File){
        this.userId = userId;
        this.plant = plant;
        this.desiredPlant = desiredPlant;
        this.city = city;
        this.image = image;
    }
}