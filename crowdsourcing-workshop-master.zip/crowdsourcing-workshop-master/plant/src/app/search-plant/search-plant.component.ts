import { Component, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { HowToTreatService } from '../services/how-to-treat-service';

@Component({
  selector: 'app-search-plant',
  template: `<div></div>`,
  providers: [HowToTreatService]
})
export class SearchPlantComponent implements OnInit {
  public filteredResults!: string[];
  public results!: any[];
  public selectedPlant: any;
  public resultsInfo!: any[];
  public showData: boolean = false;
  protected subscriptions = new Subscription();
  
  constructor(protected howToTreatService: HowToTreatService){}
  ngOnInit(): void {
    this.subscriptions.add(this.howToTreatService.getAllPlants().subscribe(data => {this.results = data;})
    )
    this.subscriptions.add(this.howToTreatService.getPlantsTreatConditions().subscribe(data => {this.resultsInfo = data;})
    )
  }

  ngOnDestroy(): void {
    if (this.subscriptions) {
      this.subscriptions.unsubscribe();
    }
  }

  public search(event:any) { //autoComplete
    let filtered : any[] = [];
    let query = event.query;
    let plant;
    for(let i=0; i<this.results.length; i++){
      plant = this.results[i].plantName;
      if(plant.toLowerCase().indexOf(query.toLowerCase()) == 0){
        filtered.push(plant);
      }
    }
    this.filteredResults = filtered;
  }

  public onSelect(event:any){
    this.selectedPlant = this.resultsInfo.find((x:any)=> x.plantName == event);
    this.showData = true;
  }
}

 