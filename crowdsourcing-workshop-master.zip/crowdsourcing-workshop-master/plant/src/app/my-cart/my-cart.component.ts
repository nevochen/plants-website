import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { NewOffer } from '../models/NewOffer';
import { TradeRequest } from '../models/TradeRequest';
import { User } from '../models/User';
import { AuthenticationService } from '../services/AuthenticationService';
import { TradeService } from '../services/trade-service';

@Component({
  selector: 'app-my-cart',
  templateUrl: './my-cart.component.html',
  styleUrls: ['./my-cart.component.scss']
})

export class MyCartComponent implements OnInit {
  public products: TradeRequest[] = [];
  private subscriptions: Subscription = new Subscription();
  user!: any;
  
  constructor(private router: Router, private tradeService: TradeService, private authenticationService: AuthenticationService) { }

  ngOnInit(): void {
    this.subscriptions.add(this.authenticationService.currentUser.subscribe(user => {
      this.user = user;
      if(!user){
        this.user = new User('','','','','');
      }
      else{
        this.user = user;
      }
    }));

    this.subscriptions = this.tradeService.getMyCartProducts(this.user).subscribe(data => {
      this.products = data;
    });

  }
}
