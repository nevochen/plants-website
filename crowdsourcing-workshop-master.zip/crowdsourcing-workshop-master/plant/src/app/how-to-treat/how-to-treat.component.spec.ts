import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HowToTreatComponent } from './how-to-treat.component';

describe('HowToTreatComponent', () => {
  let component: HowToTreatComponent;
  let fixture: ComponentFixture<HowToTreatComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HowToTreatComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HowToTreatComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
