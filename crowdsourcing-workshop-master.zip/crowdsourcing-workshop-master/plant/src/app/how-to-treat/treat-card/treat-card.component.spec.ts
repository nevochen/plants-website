import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TreatCardComponent } from './treat-card.component';

describe('TreatCardComponent', () => {
  let component: TreatCardComponent;
  let fixture: ComponentFixture<TreatCardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TreatCardComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TreatCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
