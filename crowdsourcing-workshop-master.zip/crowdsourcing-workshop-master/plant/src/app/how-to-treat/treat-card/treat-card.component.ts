import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-treat-card',
  templateUrl: './treat-card.component.html'
})
export class TreatCardComponent implements OnInit {
@Input() title !: string;
@Input() picUrl !: string;
@Input() plantName !: string;
@Input() treatQuatity !: string;
@Input() showData !: boolean;

  constructor() { 
  }

  ngOnInit(): void {
  }

  public getParagraph() : string {
    let light =`<p>Recommended hours of light for the plant <b>${this.plantName}</b> is: <b>${this.treatQuatity}</b> hours.</p>` ;
    let watering= `<p>It is recommended for the plant <b>${this.plantName}</b> to receive water every <b>${this.treatQuatity}</b> days.</p>`;
    let temp =`<p>The ideal temperature for the plant <b>${this.plantName}</b> is around <b>${this.treatQuatity}</b> degrees celcius.</p>` ;
    
    const paragraph = {
      "Light": light,
      "Watering Frequency":watering,
      "Temperature": temp
    }
   return paragraph[this.title as keyof typeof paragraph];
  }

}
