import { Component, OnDestroy, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { SearchPlantComponent } from '../search-plant/search-plant.component';
import { HowToTreatService } from '../services/how-to-treat-service';


@Component({
  selector: 'app-how-to-treat',
  templateUrl: './how-to-treat.component.html',
  styleUrls: ['./how-to-treat.component.scss'],
  providers: [HowToTreatService]
})
export class HowToTreatComponent extends SearchPlantComponent implements OnInit, OnDestroy{
  public plantName!: string;
  public hoursOfLight!: number;
  public waterFrequency!: number;
  public temperature!: number;

  constructor(howToTreatService: HowToTreatService) {
    super(howToTreatService);
  }
}
